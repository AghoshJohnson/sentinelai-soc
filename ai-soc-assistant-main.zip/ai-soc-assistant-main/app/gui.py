"""
gui.py - Streamlit GUI for AI SOC Assistant

A professional, analyst-grade web interface for log analysis.
Provides file upload, live analysis, and rich visualisations.
"""

from __future__ import annotations

import json
import logging
import os
import sys
import tempfile
from pathlib import Path

# Bootstrap path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import streamlit as st
import streamlit.components.v1 as components

# ---------------------------------------------------------------------------
# Page configuration — must be first Streamlit call
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="AI SOC Assistant",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        "Get Help": "https://github.com/lonewolf273/ai-soc-assistant",
        "Report a bug": "https://github.com/lonewolf273/ai-soc-assistant/issues",
        "About": "# AI SOC Assistant\nOffline-first AI-powered threat detection.",
    },
)

from dotenv import load_dotenv
load_dotenv()

from app.core.analyzer import analyse_log_file, save_report, AnalysisResult
from app.core.ollama_client import OllamaClient, DEFAULT_MODEL

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.WARNING)


# ---------------------------------------------------------------------------
# CSS styling
# ---------------------------------------------------------------------------

CUSTOM_CSS = """
<style>
    /* Dark SOC theme */
    :root {
        --primary: #00d4ff;
        --danger: #ff4b4b;
        --warning: #ffa500;
        --success: #00cc88;
        --surface: #1a1a2e;
        --card: #16213e;
    }

    .stApp {
        background: linear-gradient(135deg, #0a0a1a 0%, #0d1117 100%);
        color: #e0e0e0;
    }

    /* Metric cards */
    div[data-testid="metric-container"] {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        border: 1px solid rgba(0, 212, 255, 0.2);
        border-radius: 12px;
        padding: 1rem;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
    }

    div[data-testid="metric-container"] label {
        color: #8892a4 !important;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.08em;
    }

    /* Alert boxes */
    .alert-critical {
        background: linear-gradient(135deg, rgba(255, 75, 75, 0.15), rgba(255, 75, 75, 0.05));
        border-left: 4px solid #ff4b4b;
        border-radius: 8px;
        padding: 1rem 1.25rem;
        margin: 0.5rem 0;
    }
    .alert-high {
        background: linear-gradient(135deg, rgba(255, 100, 50, 0.15), rgba(255, 100, 50, 0.05));
        border-left: 4px solid #ff6432;
        border-radius: 8px;
        padding: 1rem 1.25rem;
        margin: 0.5rem 0;
    }
    .alert-medium {
        background: linear-gradient(135deg, rgba(255, 165, 0, 0.15), rgba(255, 165, 0, 0.05));
        border-left: 4px solid #ffa500;
        border-radius: 8px;
        padding: 1rem 1.25rem;
        margin: 0.5rem 0;
    }
    .alert-low {
        background: linear-gradient(135deg, rgba(0, 204, 136, 0.1), rgba(0, 204, 136, 0.03));
        border-left: 4px solid #00cc88;
        border-radius: 8px;
        padding: 1rem 1.25rem;
        margin: 0.5rem 0;
    }

    /* MITRE badge */
    .mitre-badge {
        display: inline-block;
        background: rgba(0, 212, 255, 0.15);
        border: 1px solid rgba(0, 212, 255, 0.3);
        border-radius: 6px;
        padding: 0.25rem 0.75rem;
        font-family: monospace;
        font-size: 0.85rem;
        color: #00d4ff;
        margin: 0.2rem;
    }

    /* Section headers */
    .section-header {
        font-size: 1.1rem;
        font-weight: 600;
        color: #00d4ff;
        border-bottom: 1px solid rgba(0, 212, 255, 0.2);
        padding-bottom: 0.5rem;
        margin-bottom: 1rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    /* IP table */
    .ip-row {
        display: flex;
        align-items: center;
        padding: 0.5rem 0;
        border-bottom: 1px solid rgba(255,255,255,0.05);
        font-family: monospace;
    }

    /* Severity badge */
    .sev-critical { color: #ff4b4b; font-weight: 700; font-size: 1.5rem; }
    .sev-high     { color: #ff6432; font-weight: 700; font-size: 1.5rem; }
    .sev-medium   { color: #ffa500; font-weight: 700; font-size: 1.5rem; }
    .sev-low      { color: #00cc88; font-weight: 700; font-size: 1.5rem; }

    /* Sidebar */
    section[data-testid="stSidebar"] {
        background: linear-gradient(180deg, #0d1117 0%, #0a0a1a 100%);
        border-right: 1px solid rgba(0, 212, 255, 0.1);
    }
</style>
"""

st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------

def render_sidebar() -> dict:
    """Render the configuration sidebar and return settings dict."""
    with st.sidebar:
        st.markdown("### 🛡️ SOC Assistant")
        st.markdown("*Offline AI-Powered Threat Detection*")
        st.divider()

        st.markdown("**⚙️ Analysis Settings**")
        log_type = st.selectbox(
            "Log Type",
            options=["auto", "ssh", "web"],
            index=0,
            help="Auto-detection works for most files.",
        )

        model = st.text_input(
            "Ollama Model",
            value=os.getenv("OLLAMA_MODEL", DEFAULT_MODEL),
            help="Model name must be installed locally.",
        )

        enable_ai = st.toggle("Enable AI Analysis", value=True)

        enable_enrich = st.toggle("Enable IP Enrichment", value=False,
                                  help="Requires ABUSEIPDB_API_KEY in .env")

        st.divider()
        st.markdown("**🔌 System Status**")

        # Ollama status
        client = OllamaClient(model=model)
        if client.is_available():
            st.success("✅ Ollama: Running")
            if client.model_is_available():
                st.success(f"✅ Model `{model}`: Ready")
            else:
                st.warning(f"⚠️ Model `{model}` not found\n\n`ollama pull {model}`")
        else:
            st.error("❌ Ollama: Offline\n\nRun `ollama serve` to enable AI")

        # AbuseIPDB status
        abuseipdb_key = os.getenv("ABUSEIPDB_API_KEY", "")
        if abuseipdb_key:
            st.success("✅ AbuseIPDB: Configured")
        else:
            st.info("ℹ️ AbuseIPDB: Not configured")

        st.divider()
        st.markdown("**📂 Load Sample Logs**")

        samples_dir = Path(__file__).parent.parent / "data" / "samples"
        sample_files = list(samples_dir.glob("*.log")) if samples_dir.exists() else []

        selected_sample = st.selectbox(
            "Choose sample log",
            options=["(none)"] + [f.name for f in sample_files],
        )

        st.divider()
        st.markdown("*AI SOC Assistant v1.0*", unsafe_allow_html=False)
        st.caption("Built for cybersecurity portfolio demonstration.")

    return {
        "log_type": log_type,
        "model": model,
        "enable_ai": enable_ai,
        "enable_enrich": enable_enrich,
        "selected_sample": selected_sample,
        "samples_dir": samples_dir,
    }


# ---------------------------------------------------------------------------
# Result display sections
# ---------------------------------------------------------------------------

def render_overview_metrics(result: AnalysisResult) -> None:
    sev = result.severity
    col1, col2, col3, col4, col5 = st.columns(5)
    with col1:
        st.metric("Events Parsed", f"{result.event_count:,}")
    with col2:
        st.metric("Alerts Raised", result.alert_count)
    with col3:
        st.metric("MITRE Techniques", len(result.mitre_techniques))
    with col4:
        st.metric("Threat Score", f"{sev.score}/100")
    with col5:
        st.metric("Unique Source IPs", len(result.top_source_ips))


def render_severity_banner(result: AnalysisResult) -> None:
    sev = result.severity
    colour_map = {
        "CRITICAL": "#ff4b4b",
        "HIGH": "#ff6432",
        "MEDIUM": "#ffa500",
        "LOW": "#00cc88",
    }
    colour = colour_map.get(sev.severity, "#ffffff")

    st.markdown(
        f"""
        <div style="
            background: linear-gradient(135deg, {colour}22, {colour}08);
            border: 2px solid {colour};
            border-radius: 16px;
            padding: 1.5rem 2rem;
            margin: 1rem 0;
            text-align: center;
        ">
            <div style="font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.1em;
                        color: #8892a4; margin-bottom: 0.5rem;">Overall Severity</div>
            <div style="font-size: 2.5rem; font-weight: 800; color: {colour};
                        letter-spacing: 0.05em;">{sev.severity}</div>
            <div style="font-size: 0.9rem; color: #c0c8d4; margin-top: 0.75rem;
                        max-width: 600px; margin-left: auto; margin-right: auto;">
                {sev.summary}
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_alerts(result: AnalysisResult) -> None:
    st.markdown('<div class="section-header">🚨 Rule-Based Alerts</div>', unsafe_allow_html=True)

    if not result.alerts:
        st.success("✅ No rule-based alerts triggered.")
        return

    confidence_colours = {"high": "🔴", "medium": "🟡", "low": "🟢"}
    severity_class_map = {
        "high": "alert-critical",
        "medium": "alert-medium",
        "low": "alert-low",
    }

    for alert in result.alerts:
        conf = alert.get("confidence", "low").lower()
        icon = confidence_colours.get(conf, "⚪")
        css_class = severity_class_map.get(conf, "alert-low")

        st.markdown(
            f"""
            <div class="{css_class}">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <span style="font-weight:700; font-size:1rem;">
                        {icon} [{alert['rule_id']}] {alert['type']}
                    </span>
                    <span style="font-family:monospace; font-size:0.85rem; opacity:0.7;">
                        {alert['source_ip']}
                    </span>
                </div>
                <div style="margin-top:0.4rem; font-size:0.9rem; opacity:0.85;">
                    {alert['description']}
                </div>
                <div style="margin-top:0.5rem; font-size:0.75rem; opacity:0.6;">
                    Confidence: <strong>{alert['confidence'].upper()}</strong>
                    &nbsp;|&nbsp; Events: <strong>{alert['affected_event_count']}</strong>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )


def render_mitre(result: AnalysisResult) -> None:
    st.markdown('<div class="section-header">🛡️ MITRE ATT&CK Mapping</div>', unsafe_allow_html=True)

    if not result.mitre_techniques:
        st.info("No MITRE techniques mapped.")
        return

    # Tactic grouping
    by_tactic: dict[str, list] = {}
    for tech in result.mitre_techniques:
        tactic = tech.get("tactic", "Unknown")
        by_tactic.setdefault(tactic, []).append(tech)

    for tactic, techniques in by_tactic.items():
        st.markdown(f"**{tactic}**")
        cols = st.columns(min(len(techniques), 3))
        for i, tech in enumerate(techniques):
            with cols[i % 3]:
                st.markdown(
                    f"""
                    <div style="background:rgba(0,212,255,0.07); border:1px solid rgba(0,212,255,0.25);
                                border-radius:10px; padding:0.75rem; margin:0.25rem 0;">
                        <div style="font-family:monospace; color:#00d4ff; font-weight:700;
                                    font-size:1rem;">{tech['technique_id']}</div>
                        <div style="font-size:0.85rem; margin-top:0.2rem;">{tech['name']}</div>
                        <div style="font-size:0.75rem; opacity:0.6; margin-top:0.3rem;">
                            <a href="{tech.get('url','#')}" target="_blank"
                               style="color:#00d4ff;">ATT&CK Reference ↗</a>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
        st.markdown("")

    # Mitigations table
    with st.expander("📋 Recommended Mitigations"):
        for tech in result.mitre_techniques:
            mits = tech.get("mitigations", [])
            if mits:
                st.markdown(f"**{tech['technique_id']} — {tech['name']}**")
                for m in mits:
                    st.markdown(f"  - {m}")


def render_top_ips(result: AnalysisResult) -> None:
    st.markdown('<div class="section-header">🌐 Top Source IPs</div>', unsafe_allow_html=True)

    if not result.top_source_ips:
        st.info("No IP data available.")
        return

    rows = []

    for entry in result.top_source_ips:
        ip = entry["ip"]

        enrichment = result.ip_enrichments.get(ip)

        # 🔥 FIX: handle None properly
        if not enrichment:
            enrichment = {
                "abuseConfidenceScore": "UNKNOWN",
                "countryCode": "UNKNOWN",
                "threat_label": "UNVERIFIED"
            }

        rows.append({
            "IP Address": ip,
            "Events": entry["event_count"],
            "Event Types": ", ".join(entry.get("event_types", {}).keys()),
            "Abuse Score": enrichment.get("abuseConfidenceScore", "UNKNOWN"),
            "Country": enrichment.get("countryCode", "UNKNOWN"),
            "Threat Label": enrichment.get("threat_label", "UNKNOWN"),
        })

    import pandas as pd
    df = pd.DataFrame(rows)

    # 🔥 Optional: highlight risky IPs
    def color_row(row):
        if row["Threat Label"] in ["HIGH RISK", "KNOWN_MALICIOUS"]:
            return ["background-color: rgba(255,75,75,0.2)"] * len(row)
        elif row["Threat Label"] in ["SUSPICIOUS"]:
            return ["background-color: rgba(255,165,0,0.2)"] * len(row)
        return [""] * len(row)

    st.dataframe(df.style.apply(color_row, axis=1), use_container_width=True, hide_index=True)
    import pandas as pd
    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, hide_index=True)


def render_timeline(result: AnalysisResult) -> None:
    if not result.event_timeline:
        return

    st.markdown('<div class="section-header">📈 Event Timeline</div>', unsafe_allow_html=True)

    try:
        import pandas as pd
        timeline_data = [
            {"timestamp": t["timestamp"], "events": t["total"]}
            for t in result.event_timeline
        ]
        df = pd.DataFrame(timeline_data)
        df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
        df = df.dropna(subset=["timestamp"])
        if not df.empty:
            st.line_chart(df.set_index("timestamp")["events"])
    except Exception as exc:
        st.warning(f"Timeline chart unavailable: {exc}")


def render_ai_analysis(result: AnalysisResult) -> None:
    st.markdown('<div class="section-header">🤖 AI Analysis</div>', unsafe_allow_html=True)

    if result.ai_available:
        st.markdown(
            f"""
            <div style="background:rgba(0,212,255,0.05); border:1px solid rgba(0,212,255,0.2);
                        border-radius:12px; padding:1.5rem; font-size:0.9rem;
                        line-height:1.7; white-space:pre-wrap;">
                {result.ai_analysis}
            </div>
            """,
            unsafe_allow_html=True,
        )
    else:
        st.warning(result.ai_analysis)


def render_raw_report(result: AnalysisResult) -> None:
    with st.expander("📄 Full JSON Report"):
        st.json(result.to_dict())

    # Download button
    json_bytes = json.dumps(result.to_dict(), indent=2, default=str).encode("utf-8")
    st.download_button(
        label="⬇️ Download JSON Report",
        data=json_bytes,
        file_name=f"soc_report_{Path(result.file_path).stem}.json",
        mime="application/json",
    )


# ---------------------------------------------------------------------------
# Main app
# ---------------------------------------------------------------------------

# --- KEEP EVERYTHING ABOVE SAME ---

# (scroll down to main function and REPLACE ONLY that part)

def main() -> None:
    settings = render_sidebar()

    # Header
    st.markdown(
        """
        <div style="text-align:center; padding:2rem 0 1rem 0;">
            <div style="font-size:2.5rem; font-weight:800; letter-spacing:0.03em;
                        background:linear-gradient(90deg, #00d4ff, #0080ff);
                        -webkit-background-clip:text; -webkit-text-fill-color:transparent;">
                🛡️ AI SOC Assistant
            </div>
            <div style="color:#8892a4; font-size:1rem; margin-top:0.5rem;">
                Offline-First AI-Powered Security Operations Centre Tool
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.divider()

    # Upload
    uploaded_file = st.file_uploader("📤 Upload Log File", type=["log", "txt"])

    log_file_path = None
    temp_path = None

    if uploaded_file:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".log") as tmp:
            tmp.write(uploaded_file.getbuffer())
            temp_path = Path(tmp.name)
            log_file_path = str(temp_path)

    if st.button("🚀 Run Analysis", disabled=log_file_path is None):

        with st.spinner("Running analysis..."):
            result = analyse_log_file(
                file_path=log_file_path,
                log_type=settings["log_type"],
                enable_ai=settings["enable_ai"],
                ollama_model=settings["model"],
            )
            st.session_state["result"] = result

        if temp_path and temp_path.exists():
            temp_path.unlink(missing_ok=True)

    result = st.session_state.get("result")

    if result:

        st.divider()

        render_severity_banner(result)
        render_overview_metrics(result)

        # ================= 🔥 NEW SOC INTELLIGENCE BLOCK =================

        st.divider()

        # 🔗 Attack Chain Summary
        st.markdown('<div class="section-header">🔗 Attack Chain Summary</div>', unsafe_allow_html=True)

        st.markdown(
            f"""
            <div style="background:rgba(255,165,0,0.08);
                        border-left:4px solid #ffa500;
                        border-radius:8px;
                        padding:1rem;
                        font-size:0.95rem;
                        line-height:1.6;">
                {result.attack_chain_summary}
            </div>
            """,
            unsafe_allow_html=True,
        )

        # ⚠️ Impact Analysis
        st.markdown('<div class="section-header">⚠️ Impact Analysis</div>', unsafe_allow_html=True)

        impact = result.impact_analysis

        potential = ""
        action = ""

        if hasattr(impact, "potential_impact"):
            potential = impact.potential_impact
            action = getattr(impact, "recommended_action", "")
        elif isinstance(impact, dict):
            potential = impact.get("potential_impact", "")
            action = impact.get("recommended_action", "")

        st.markdown(
            f"""
            <div style="background:rgba(255,75,75,0.08);
                        border-left:4px solid #ff4b4b;
                        border-radius:8px;
                        padding:1rem;
                        font-size:0.95rem;
                        line-height:1.6;">
                {potential}
            </div>
            """,
            unsafe_allow_html=True,
        )

        if action:
            st.markdown("### 🛠️ Recommended Action")
            st.success(action)

        # ================= END =================

        st.divider()

        tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
            "🚨 Alerts",
            "🛡️ MITRE ATT&CK",
            "🌐 Source IPs",
            "📈 Timeline",
            "🤖 AI Analysis",
            "📄 Raw Report",
        ])

        with tab1:
            render_alerts(result)

        with tab2:
            render_mitre(result)

        with tab3:
            render_top_ips(result)

        with tab4:
            render_timeline(result)

        with tab5:
            render_ai_analysis(result)

        with tab6:
            render_raw_report(result)

        # Save report
        output_dir = Path("outputs/reports")
        try:
            report_path = save_report(result, output_dir)
            st.caption(f"📁 Report auto-saved: `{report_path}`")
        except Exception as exc:
            logger.warning("Could not save report: %s", exc)

    else:
        st.markdown(
            """
            <div style="text-align:center; padding:4rem 2rem; opacity:0.5;">
                <div style="font-size:4rem;">🔍</div>
                <div style="font-size:1.1rem; margin-top:1rem;">
                    Upload a log file to begin analysis.
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )


if __name__ == "__main__":
    main()