"""
test_parser.py - Unit Tests for Log Parser Module

Tests SSH and web log parsing with real-world log line fixtures.
"""

from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

# Bootstrap path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.core.parser import (
    parse_ssh_log,
    parse_web_log,
    parse_log_file,
    detect_log_type,
)


class TestSSHParser(unittest.TestCase):
    """Tests for SSH log parsing."""

    def test_parse_failed_login_invalid_user(self):
        line = "Dec 10 04:11:21 webserver sshd[12341]: Failed password for invalid user admin from 192.168.1.105 port 54321 ssh2"
        event = parse_ssh_log(line)
        self.assertIsNotNone(event)
        self.assertEqual(event["event_type"], "SSH_FAILED_LOGIN")
        self.assertEqual(event["source_ip"], "192.168.1.105")
        self.assertEqual(event["username"], "admin")
        self.assertEqual(event["destination_port"], 54321)
        self.assertIn("T", event["timestamp"])  # ISO format

    def test_parse_failed_login_valid_username_field(self):
        line = "Dec 10 04:12:15 webserver sshd[12360]: Failed password for root from 203.0.113.42 port 11111 ssh2"
        event = parse_ssh_log(line)
        self.assertIsNotNone(event)
        self.assertEqual(event["event_type"], "SSH_FAILED_LOGIN")
        self.assertEqual(event["username"], "root")
        self.assertEqual(event["source_ip"], "203.0.113.42")

    def test_parse_accepted_login(self):
        line = "Dec 10 04:12:10 webserver sshd[12359]: Accepted password for admin from 10.0.0.5 port 22345 ssh2"
        event = parse_ssh_log(line)
        self.assertIsNotNone(event)
        self.assertEqual(event["event_type"], "SSH_ACCEPTED_LOGIN")
        self.assertEqual(event["source_ip"], "10.0.0.5")
        self.assertEqual(event["username"], "admin")

    def test_parse_disconnect(self):
        line = "Dec 10 04:15:00 webserver sshd[12370]: Connection closed by 192.168.1.105 port 54321 [preauth]"
        event = parse_ssh_log(line)
        self.assertIsNotNone(event)
        self.assertEqual(event["event_type"], "SSH_DISCONNECT")
        self.assertEqual(event["source_ip"], "192.168.1.105")

    def test_parse_unrecognised_line_returns_none(self):
        line = "This is not an SSH log line at all."
        event = parse_ssh_log(line)
        self.assertIsNone(event)

    def test_parse_empty_line_returns_none(self):
        event = parse_ssh_log("")
        self.assertIsNone(event)

    def test_parse_raw_field_preserved(self):
        line = "Dec 10 04:11:21 webserver sshd[99]: Failed password for invalid user oracle from 10.1.2.3 port 9999 ssh2"
        event = parse_ssh_log(line)
        self.assertIsNotNone(event)
        self.assertIn("raw", event)
        self.assertEqual(event["raw"], line.strip())


class TestWebParser(unittest.TestCase):
    """Tests for Apache/Nginx web log parsing."""

    def test_parse_basic_get_request(self):
        line = '192.168.1.200 - - [10/Dec/2023:08:23:11 +0000] "GET /index.php?id=1 HTTP/1.1" 200 4523 "-" "Mozilla/5.0"'
        event = parse_web_log(line)
        self.assertIsNotNone(event)
        self.assertEqual(event["event_type"], "WEB_REQUEST")
        self.assertEqual(event["source_ip"], "192.168.1.200")
        self.assertEqual(event["http_method"], "GET")
        self.assertEqual(event["status_code"], 200)
        self.assertEqual(event["response_size"], 4523)
        self.assertIn("Mozilla", event["user_agent"])

    def test_parse_post_request(self):
        line = '203.0.113.99 - - [10/Dec/2023:08:24:00 +0000] "POST /login.php HTTP/1.1" 200 1024 "-" "curl/7.68.0"'
        event = parse_web_log(line)
        self.assertIsNotNone(event)
        self.assertEqual(event["http_method"], "POST")
        self.assertEqual(event["request_path"], "/login.php")
        self.assertEqual(event["status_code"], 200)

    def test_parse_timestamp_format(self):
        line = '10.10.10.55 - - [10/Dec/2023:09:01:00 +0000] "GET /index.php HTTP/1.1" 200 4523 "-" "Mozilla/5.0"'
        event = parse_web_log(line)
        self.assertIsNotNone(event)
        self.assertIn("2023", event["timestamp"])

    def test_parse_sqli_path_preserved(self):
        line = '192.168.1.200 - - [10/Dec/2023:08:23:18 +0000] "GET /login.php?user=admin\' OR \'1\'=\'1 HTTP/1.1" 200 1024 "-" "sqlmap/1.7"'
        event = parse_web_log(line)
        self.assertIsNotNone(event)
        self.assertIn("OR", event["request_path"])

    def test_parse_scanner_user_agent(self):
        line = '203.0.113.99 - - [10/Dec/2023:08:24:15 +0000] "GET /wp-login.php HTTP/1.1" 200 1024 "-" "WPScan v3.8.22"'
        event = parse_web_log(line)
        self.assertIsNotNone(event)
        self.assertIn("WPScan", event["user_agent"])

    def test_parse_unrecognised_line(self):
        line = "not a web log line"
        event = parse_web_log(line)
        self.assertIsNone(event)


class TestLogFileParser(unittest.TestCase):
    """Integration tests for parse_log_file()."""

    def _write_temp_log(self, content: str, suffix: str = ".log") -> Path:
        """Write content to a temp file and return its path."""
        tmp = tempfile.NamedTemporaryFile(
            delete=False, mode="w", suffix=suffix, encoding="utf-8"
        )
        tmp.write(content)
        tmp.flush()
        tmp.close()
        return Path(tmp.name)

    def test_parse_ssh_file_returns_events(self):
        content = "\n".join([
            "Dec 10 04:11:21 webserver sshd[1]: Failed password for invalid user admin from 1.2.3.4 port 111 ssh2",
            "Dec 10 04:11:22 webserver sshd[2]: Failed password for invalid user root from 1.2.3.4 port 112 ssh2",
            "Some unrelated line",
        ])
        path = self._write_temp_log(content)
        events = parse_log_file(str(path), log_type="ssh")
        self.assertEqual(len(events), 2)
        self.assertTrue(all(e["event_type"] == "SSH_FAILED_LOGIN" for e in events))

    def test_parse_web_file_returns_events(self):
        content = "\n".join([
            '1.2.3.4 - - [10/Dec/2023:08:00:01 +0000] "GET /index.php HTTP/1.1" 200 1000 "-" "Mozilla/5.0"',
            '5.6.7.8 - - [10/Dec/2023:08:00:05 +0000] "POST /login.php HTTP/1.1" 302 512 "-" "curl/7.68"',
        ])
        path = self._write_temp_log(content)
        events = parse_log_file(str(path), log_type="web")
        self.assertEqual(len(events), 2)
        self.assertTrue(all(e["event_type"] == "WEB_REQUEST" for e in events))

    def test_parse_nonexistent_file_raises(self):
        with self.assertRaises(FileNotFoundError):
            parse_log_file("/nonexistent/path/file.log")

    def test_auto_detect_ssh(self):
        content = "Dec 10 04:11:21 webserver sshd[1]: Failed password for invalid user admin from 1.2.3.4 port 111 ssh2\n" * 5
        path = self._write_temp_log(content)
        events = parse_log_file(str(path), log_type="auto")
        self.assertGreater(len(events), 0)
        self.assertTrue(all(e["event_type"] == "SSH_FAILED_LOGIN" for e in events))

    def test_empty_file_returns_empty_list(self):
        path = self._write_temp_log("")
        events = parse_log_file(str(path), log_type="ssh")
        self.assertEqual(events, [])


class TestLogTypeDetection(unittest.TestCase):
    """Tests for auto log-type detection."""

    def test_detect_ssh(self):
        content = "Dec 10 04:11:21 webserver sshd[1]: Failed password for invalid user admin from 1.2.3.4 port 111 ssh2\n" * 10
        tmp = tempfile.NamedTemporaryFile(delete=False, mode="w", suffix=".log")
        tmp.write(content)
        tmp.close()
        detected = detect_log_type(Path(tmp.name))
        self.assertEqual(detected, "ssh")

    def test_detect_web(self):
        content = '1.2.3.4 - - [10/Dec/2023:08:00:01 +0000] "GET /index.php HTTP/1.1" 200 1000 "-" "Mozilla/5.0"\n' * 10
        tmp = tempfile.NamedTemporaryFile(delete=False, mode="w", suffix=".log")
        tmp.write(content)
        tmp.close()
        detected = detect_log_type(Path(tmp.name))
        self.assertEqual(detected, "web")


if __name__ == "__main__":
    unittest.main(verbosity=2)
