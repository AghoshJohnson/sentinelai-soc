"""
test_analyzer.py - Unit Tests for the Analysis Pipeline

Tests rule detection, MITRE mapping, severity scoring, and the
full analysis pipeline in offline mode (no AI, no external APIs).
"""

from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.core.rules import (
    detect_ssh_brute_force,
    detect_sql_injection,
    detect_xss,
    detect_path_traversal,
    detect_scanner_activity,
    detect_sensitive_file_probe,
    detect_ssh_successful_after_failures,
    run_all_rules,
)
from app.core.mitre import (
    map_alert_to_mitre,
    build_mitre_summary,
    get_technique_by_id,
)
from app.core.scorer import compute_severity
from app.core.analyzer import analyse_log_file


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

def _make_ssh_failed(ip: str, count: int) -> list[dict]:
    return [
        {
            "timestamp": f"2023-12-10T04:11:{i:02d}",
            "source_ip": ip,
            "username": "admin",
            "event_type": "SSH_FAILED_LOGIN",
            "raw": f"Failed password for invalid user admin from {ip} port {1000 + i} ssh2",
        }
        for i in range(count)
    ]


def _make_ssh_accepted(ip: str) -> dict:
    return {
        "timestamp": "2023-12-10T04:20:00",
        "source_ip": ip,
        "username": "admin",
        "event_type": "SSH_ACCEPTED_LOGIN",
        "raw": f"Accepted password for admin from {ip} port 22345 ssh2",
    }


def _make_web_request(ip: str, path: str, ua: str = "Mozilla/5.0") -> dict:
    return {
        "timestamp": "2023-12-10T08:23:00+00:00",
        "source_ip": ip,
        "http_method": "GET",
        "request_path": path,
        "status_code": 200,
        "response_size": 1024,
        "user_agent": ua,
        "event_type": "WEB_REQUEST",
        "raw": f'1.2.3.4 - - [10/Dec/2023:08:23:00 +0000] "GET {path} HTTP/1.1" 200 1024 "-" "{ua}"',
    }


# ---------------------------------------------------------------------------
# Rule tests
# ---------------------------------------------------------------------------

class TestSSHBruteForceRule(unittest.TestCase):

    def test_triggers_at_threshold(self):
        events = _make_ssh_failed("1.2.3.4", 5)
        alerts = detect_ssh_brute_force(events)
        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0].type, "SSH Brute Force")
        self.assertEqual(alerts[0].source_ip, "1.2.3.4")

    def test_does_not_trigger_below_threshold(self):
        events = _make_ssh_failed("1.2.3.4", 4)
        alerts = detect_ssh_brute_force(events)
        self.assertEqual(len(alerts), 0)

    def test_multiple_ips_detected_independently(self):
        events = _make_ssh_failed("1.1.1.1", 6) + _make_ssh_failed("2.2.2.2", 7)
        alerts = detect_ssh_brute_force(events)
        self.assertEqual(len(alerts), 2)
        detected_ips = {a.source_ip for a in alerts}
        self.assertIn("1.1.1.1", detected_ips)
        self.assertIn("2.2.2.2", detected_ips)

    def test_high_volume_confidence(self):
        events = _make_ssh_failed("9.9.9.9", 25)
        alerts = detect_ssh_brute_force(events)
        self.assertEqual(alerts[0].confidence, "high")

    def test_alert_has_metadata(self):
        events = _make_ssh_failed("1.2.3.4", 8)
        alerts = detect_ssh_brute_force(events)
        self.assertIn("failed_count", alerts[0].metadata)
        self.assertEqual(alerts[0].metadata["failed_count"], 8)


class TestSQLInjectionRule(unittest.TestCase):

    def test_detects_union_select(self):
        events = [
            _make_web_request("1.2.3.4", "/products.php?id=1 UNION SELECT null,null,null--"),
            _make_web_request("1.2.3.4", "/products.php?id=2 UNION SELECT username,password FROM users--"),
            _make_web_request("1.2.3.4", "/login.php?user=admin' OR '1'='1"),
        ]
        alerts = detect_sql_injection(events)
        self.assertGreater(len(alerts), 0)
        alert_types = [a.type for a in alerts]
        self.assertIn("SQL Injection", alert_types)

    def test_detects_sleep_payload(self):
        events = [
            _make_web_request("5.6.7.8", "/api/users?id=1' AND SLEEP(5)--"),
            _make_web_request("5.6.7.8", "/api/users?id=1' AND SLEEP(3)--"),
            _make_web_request("5.6.7.8", "/api/users?id=1' AND SLEEP(1)--"),
        ]
        alerts = detect_sql_injection(events)
        self.assertGreater(len(alerts), 0)

    def test_clean_request_not_flagged(self):
        events = [
            _make_web_request("10.0.0.1", "/index.php?id=1"),
            _make_web_request("10.0.0.1", "/about.php"),
        ]
        alerts = detect_sql_injection(events)
        self.assertEqual(len(alerts), 0)


class TestXSSRule(unittest.TestCase):

    def test_detects_script_tag(self):
        events = [
            _make_web_request("1.2.3.4", "/search.php?q=<script>alert(1)</script>"),
        ]
        alerts = detect_xss(events)
        self.assertGreater(len(alerts), 0)
        self.assertEqual(alerts[0].type, "Cross-Site Scripting (XSS)")

    def test_detects_javascript_protocol(self):
        events = [
            _make_web_request("1.2.3.4", "/page?url=javascript:alert(document.cookie)"),
        ]
        alerts = detect_xss(events)
        self.assertGreater(len(alerts), 0)


class TestPathTraversalRule(unittest.TestCase):

    def test_detects_dotdot(self):
        events = [
            _make_web_request("1.2.3.4", "/admin.php?file=../../../../etc/passwd"),
        ]
        alerts = detect_path_traversal(events)
        self.assertGreater(len(alerts), 0)
        self.assertEqual(alerts[0].type, "Path Traversal")
        self.assertEqual(alerts[0].confidence, "high")

    def test_detects_encoded_traversal(self):
        events = [
            _make_web_request("2.3.4.5", "/get?path=%2e%2e%2fetc%2fpasswd"),
        ]
        alerts = detect_path_traversal(events)
        self.assertGreater(len(alerts), 0)


class TestScannerDetectionRule(unittest.TestCase):

    def test_detects_sqlmap(self):
        events = [
            _make_web_request("9.8.7.6", "/login.php", ua="sqlmap/1.7.8#stable"),
            _make_web_request("9.8.7.6", "/admin.php", ua="sqlmap/1.7.8#stable"),
        ]
        alerts = detect_scanner_activity(events)
        self.assertGreater(len(alerts), 0)
        self.assertEqual(alerts[0].type, "Automated Scanner Detected")

    def test_detects_wpscan(self):
        events = [
            _make_web_request("1.1.1.2", "/wp-login.php", ua="WPScan v3.8.22"),
        ]
        alerts = detect_scanner_activity(events)
        self.assertGreater(len(alerts), 0)

    def test_legitimate_browser_not_flagged(self):
        events = [
            _make_web_request("10.0.0.1", "/index.php",
                               ua="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"),
        ]
        alerts = detect_scanner_activity(events)
        self.assertEqual(len(alerts), 0)


class TestBruteForceSuccessRule(unittest.TestCase):

    def test_detects_success_after_failures(self):
        events = (
            _make_ssh_failed("1.2.3.4", 10)
            + [_make_ssh_accepted("1.2.3.4")]
        )
        alerts = detect_ssh_successful_after_failures(events)
        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0].type, "Brute Force Success")
        self.assertEqual(alerts[0].confidence, "high")

    def test_no_alert_without_prior_failures(self):
        events = [_make_ssh_accepted("10.0.0.5")]
        alerts = detect_ssh_successful_after_failures(events)
        self.assertEqual(len(alerts), 0)


class TestRunAllRules(unittest.TestCase):

    def test_combined_ssh_and_web(self):
        ssh_events = _make_ssh_failed("1.2.3.4", 10)
        web_events = [
            _make_web_request("5.6.7.8", "/login.php?u=admin' OR '1'='1--"),
            _make_web_request("5.6.7.8", "/products.php?id=1 UNION SELECT null--"),
            _make_web_request("5.6.7.8", "/search.php?id=1 UNION SELECT null--"),
        ]
        all_alerts = run_all_rules(ssh_events + web_events)
        alert_types = {a.type for a in all_alerts}
        self.assertIn("SSH Brute Force", alert_types)
        self.assertIn("SQL Injection", alert_types)


# ---------------------------------------------------------------------------
# MITRE mapping tests
# ---------------------------------------------------------------------------

class TestMitreMapping(unittest.TestCase):

    def test_ssh_brute_force_maps_T1110(self):
        techniques = map_alert_to_mitre("SSH Brute Force")
        ids = [t["technique_id"] for t in techniques]
        self.assertIn("T1110", ids)

    def test_sql_injection_maps_T1190(self):
        techniques = map_alert_to_mitre("SQL Injection")
        ids = [t["technique_id"] for t in techniques]
        self.assertIn("T1190", ids)

    def test_unknown_type_returns_empty(self):
        techniques = map_alert_to_mitre("Nonexistent Attack Type")
        self.assertEqual(techniques, [])

    def test_get_technique_by_id(self):
        tech = get_technique_by_id("T1110")
        self.assertIsNotNone(tech)
        self.assertEqual(tech["technique_id"], "T1110")
        self.assertIn("tactic", tech)
        self.assertIn("url", tech)

    def test_build_mitre_summary_deduplicates(self):
        alerts = [
            {"type": "SSH Brute Force"},
            {"type": "SSH Brute Force"},  # duplicate
            {"type": "SQL Injection"},
        ]
        summary = build_mitre_summary(alerts)
        ids = [t["technique_id"] for t in summary]
        # Should not have duplicates
        self.assertEqual(len(ids), len(set(ids)))


# ---------------------------------------------------------------------------
# Severity scoring tests
# ---------------------------------------------------------------------------

class TestSeverityScorer(unittest.TestCase):

    def test_no_alerts_is_low(self):
        result = compute_severity(events=[], alerts=[], mitre_techniques=[])
        self.assertEqual(result.severity, "LOW")

    def test_brute_force_success_is_high_or_critical(self):
        events = _make_ssh_failed("1.2.3.4", 20) + [_make_ssh_accepted("1.2.3.4")]
        all_alerts = run_all_rules(events)
        alert_dicts = [a.to_dict() for a in all_alerts]
        mitre = build_mitre_summary(alert_dicts)
        result = compute_severity(events, alert_dicts, mitre)
        self.assertIn(result.severity, ["HIGH", "CRITICAL"])

    def test_score_in_range(self):
        events = _make_ssh_failed("1.2.3.4", 5)
        alert_dicts = [a.to_dict() for a in run_all_rules(events)]
        mitre = build_mitre_summary(alert_dicts)
        result = compute_severity(events, alert_dicts, mitre)
        self.assertGreaterEqual(result.score, 0)
        self.assertLessEqual(result.score, 100)

    def test_result_has_breakdown(self):
        result = compute_severity(events=[], alerts=[], mitre_techniques=[])
        self.assertIn("alert_score", result.breakdown)
        self.assertIn("mitre_score", result.breakdown)
        self.assertIn("total_score", result.breakdown)


# ---------------------------------------------------------------------------
# Full pipeline integration test (no AI, no external APIs)
# ---------------------------------------------------------------------------

class TestFullPipeline(unittest.TestCase):

    def _write_temp_log(self, content: str) -> str:
        tmp = tempfile.NamedTemporaryFile(delete=False, mode="w", suffix=".log", encoding="utf-8")
        tmp.write(content)
        tmp.close()
        return tmp.name

    def test_pipeline_ssh_brute_force(self):
        ssh_lines = "\n".join(
            f"Dec 10 04:11:{i:02d} webserver sshd[{1000+i}]: "
            f"Failed password for invalid user admin from 1.2.3.4 port {2000+i} ssh2"
            for i in range(15)
        )
        path = self._write_temp_log(ssh_lines)
        result = analyse_log_file(
            file_path=path,
            log_type="ssh",
            enable_ai=False,
        )
        self.assertGreater(result.event_count, 0)
        self.assertGreater(result.alert_count, 0)
        alert_types = {a["type"] for a in result.alerts}
        self.assertIn("SSH Brute Force", alert_types)
        self.assertIsNotNone(result.severity)
        self.assertGreater(result.severity.score, 0)
        mitre_ids = {t["technique_id"] for t in result.mitre_techniques}
        self.assertIn("T1110", mitre_ids)

    def test_pipeline_sql_injection(self):
        web_lines = "\n".join([
            '5.6.7.8 - - [10/Dec/2023:08:23:18 +0000] "GET /login.php?user=admin\' OR \'1\'=\'1 HTTP/1.1" 200 1024 "-" "sqlmap/1.7"',
            '5.6.7.8 - - [10/Dec/2023:08:23:20 +0000] "GET /products.php?id=1 UNION SELECT null,null,null-- HTTP/1.1" 500 512 "-" "sqlmap/1.7"',
            '5.6.7.8 - - [10/Dec/2023:08:23:22 +0000] "GET /products.php?id=1 UNION SELECT username,password FROM users-- HTTP/1.1" 200 2048 "-" "sqlmap/1.7"',
        ])
        path = self._write_temp_log(web_lines)
        result = analyse_log_file(
            file_path=path,
            log_type="web",
            enable_ai=False,
        )
        self.assertGreater(result.event_count, 0)
        alert_types = {a["type"] for a in result.alerts}
        self.assertTrue(
            "SQL Injection" in alert_types or "Automated Scanner Detected" in alert_types
        )

    def test_pipeline_produces_top_ips(self):
        ssh_lines = "\n".join(
            f"Dec 10 04:11:{i:02d} webserver sshd[{1000+i}]: "
            f"Failed password for invalid user root from 9.9.9.9 port {3000+i} ssh2"
            for i in range(8)
        )
        path = self._write_temp_log(ssh_lines)
        result = analyse_log_file(file_path=path, log_type="ssh", enable_ai=False)
        self.assertGreater(len(result.top_source_ips), 0)
        self.assertEqual(result.top_source_ips[0]["ip"], "9.9.9.9")

    def test_pipeline_empty_file(self):
        path = self._write_temp_log("")
        result = analyse_log_file(file_path=path, log_type="ssh", enable_ai=False)
        self.assertEqual(result.event_count, 0)
        self.assertEqual(result.alert_count, 0)

    def test_result_serialisable(self):
        import json
        ssh_lines = "\n".join(
            f"Dec 10 04:11:{i:02d} webserver sshd[{1000+i}]: "
            f"Failed password for invalid user admin from 1.1.1.1 port {2000+i} ssh2"
            for i in range(6)
        )
        path = self._write_temp_log(ssh_lines)
        result = analyse_log_file(file_path=path, log_type="ssh", enable_ai=False)
        result_dict = result.to_dict()
        serialised = json.dumps(result_dict, default=str)
        self.assertIsInstance(serialised, str)
        parsed = json.loads(serialised)
        self.assertIn("meta", parsed)
        self.assertIn("severity", parsed)
        self.assertIn("alerts", parsed)


if __name__ == "__main__":
    unittest.main(verbosity=2)
